import React, { Component } from 'react';
class Header extends Component {
    render() {
        return (
            <div className="sidenav text-center">
                <div className="side_top">
                    <img src={this.props.res.profileImage} alt="news image" className="img-fluid navimg" />
                    <h1 className="top_hd mt-2" style={{'fontSize':this.props.res.h1 ,'color':this.props.res.hColor}}><a href="#">Conjoint</a></h1>
                    <p className="top_hdp mt-2" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}>Fermentum lobortis non tristique ante proin sociis</p>
                </div>

                <header>
                    <div className="nav-top">
                        <nav className="mnu mx-auto">
                            <label for="drop" className="toggle">Menu</label>
                            <input type="checkbox" id="drop" />
                            <ul className="menu">
                                <li className="active"><a href="#home" className="scroll">Home</a></li>
                                <li className="mt-sm-3"><a href="#about" className="scroll">About</a></li>
                                <li className="mt-sm-3"><a href="#services" className="scroll">Services</a></li>
                                <li className="mt-sm-3"><a href="#news" className="scroll">News</a></li>
                                <li className="mt-sm-3"><a href="#contact" className="scroll">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                </header>

            </div>

        );
    }
}

export default Header;
