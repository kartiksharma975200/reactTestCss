import React, { Component } from 'react';
class Contact extends Component {
    render() {
        return (
            <section className="wedo" id="contact">
                <h3 className="w3_head mb-4 text-left" style={{'fontSize':this.props.res.h3 ,'color':this.props.res.hColor}}> Contact Me</h3>
                <p className="iner mt-md-5 text-left" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}> Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. Primis aliquam mus lacinia lobortis.Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. </p>
               
                <div className="cpy-right text-center">
                    <p>© 2019 . All rights reserved | Design by
					<a href="#"> React Test.</a>
                    </p>
                </div>
            </section>

        );
    }
}

export default Contact;
