import React, { Component } from 'react';
class About extends Component {
    render() {
        return (
            <section className="slide-wrapper" id="about">
                <h2 className="w3_head mb-4" style={{'fontSize':this.props.res.h2 ,'color':this.props.res.hColor}} >About Me </h2>
                <h4 className="main_hd" style={{'fontSize':this.props.res.h4 ,'color':this.props.res.hColor}}> Fermentum lobortis non tristique ante proin sociis <br />accumsan lobortis auctor etiam.</h4>
                <p className="iner mt-md-5" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}> Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. Primis aliquam mus lacinia lobortis phasellus suscipit. Fermentum lobortis non tristique ante proin sociis accumsan lobortis. Auctor etiam porttitor phasellus tempus cubilia ultrices tempor sagittis. Nisl fermentum consequat integer interdum integer purus sapien. Nibh eleifend nulla nascetur pharetra commodo mi augue interdum tellus. Ornare cursus augue feugiat sodales velit lorem. Semper elementum ullamcorper lacinia natoque aenean scelerisque.</p>
            </section>

        );
    }
}

export default About;
