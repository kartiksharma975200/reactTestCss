import React, { Component } from 'react';
class Services extends Component {
    render() {
        return (
            <section className="services" id="services">
                <div className="container">
                    <h3 className="w3_head mb-4 text-left" style={{'fontSize':this.props.res.h3 ,'color':this.props.res.hColor}}> Services</h3>
                    <p className="iner mt-md-5 text-left" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}
                    > Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. Primis aliquam mus lacinia lobortis.Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. </p>
                    <ul className="list-unstyled mt-5">
                        <li>
                            <div className="row">
                                <div className="col-2 ic-lft">
                                    <span className="fa fa-code"></span>
                                </div>
                                <div className="col-10">
                                    <h6 style={{'fontSize':this.props.res.h6 ,'color':this.props.res.hColor}}>Fermentum adipiscing </h6>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="row">
                                <div className="col-2 ic-lft">
                                    <span className="fa fa-cubes"></span>
                                </div>
                                <div className="col-10">
                                    <h6 style={{'fontSize':this.props.res.h6 ,'color':this.props.res.hColor}}>Fermentum lobortis </h6>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="row">
                                <div className="col-2 ic-lft">
                                    <span className="fa fa-book"></span>
                                </div>
                                <div className="col-10">
                                    <h6 style={{'fontSize':this.props.res.h6 ,'color':this.props.res.hColor}}>Tristique ante </h6>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="row">
                                <div className="col-2 ic-lft">
                                    <span className="fa fa-coffee"></span>
                                </div>
                                <div className="col-10">
                                    <h6 style={{'fontSize':this.props.res.h6 ,'color':this.props.res.hColor}}>Nascetur adipiscing</h6>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="row">
                                <div className="col-2 ic-lft">
                                    <span className="fa fa-bolt"></span>
                                </div>
                                <div className="col-10">
                                    <h6 style={{'fontSize':this.props.res.h6 ,'color':this.props.res.hColor}}>Primis aliquam mus</h6>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div className="row">
                                <div className="col-2 ic-lft">
                                    <span className="fa fa-cog"></span>
                                </div>
                                <div className="col-10">
                                    <h6 style={{'fontSize':this.props.res.h6 ,'color':this.props.res.hColor}}>Lobortis phasellus</h6>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>

        );
    }
}

export default Services;
