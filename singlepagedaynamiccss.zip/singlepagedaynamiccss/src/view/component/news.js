import React, { Component } from 'react';
class News extends Component {
    render() {
        return (
            <div className="news" id="news">
		<h3 className="w3_head mb-4 text-left" style={{'fontSize':this.props.res.h3 ,'color':this.props.res.hColor}}> News</h3>
		<p className="iner mt-md-5 text-left" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}> Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. Primis aliquam mus lacinia lobortis.Nunc fermentum adipiscing tempor cursus nascetur adipiscing adipiscing. </p>
				<div className="row news-grids-left mt-5">
					<div className="col-lg-5 news_top">
						<img src="images/g1.jpg" alt="news image" className="img-fluid" />
					</div>
					<div className="col-lg-7 news_top1">
						<h5 style={{'fontSize':this.props.res.h5 ,'color':this.props.res.hColor}}>Nulla pellentesque</h5>
						<p className="mt-3" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}>Integer eu ante ornare amet commetus vestibulum blandit integer in curae ac faucibus integer adipiscing ornare amet.</p>
					</div>
				</div>
				<div className="row news-grids-middle">
					<div className="col-lg-5 news_top">
						<img src="images/g2.jpg" alt="news image" className="img-fluid" />
					</div>
					<div className="col-lg-7 news_top1">
						<h5 style={{'fontSize':this.props.res.h5 ,'color':this.props.res.hColor}}>Nulla pellentesque</h5>
						<p className="mt-3" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}>Integer eu ante ornare amet commetus vestibulum blandit integer in curae ac faucibus integer adipiscing ornare amet.</p>
					</div>
				</div>
				<div className="row news-grids-right">
					<div className="col-lg-5 news_top">
						<img src="images/g3.jpg" alt="news image" className="img-fluid" />
					</div>
					<div className="col-lg-7 news_top1">
						<h5 style={{'fontSize':this.props.res.h5 ,'color':this.props.res.hColor}}>Nulla pellentesque</h5>
						<p className="mt-3" style={{'fontSize':this.props.res.p ,'color':this.props.res.pColor}}>Integer eu ante ornare amet commetus vestibulum blandit integer in curae ac faucibus integer adipiscing ornare amet.</p>
					</div>
				</div>	
				
		</div>
        );
    }
}

export default News;
