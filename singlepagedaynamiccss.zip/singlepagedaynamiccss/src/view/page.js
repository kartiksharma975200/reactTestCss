import React, { Component } from 'react';
import Header from './header';
import About from './component/about';
import Services from './component/services';
import News from './component/news';
import Contact from './component/contact';
import axios from 'axios'

class Page extends Component {
    constructor(props){
        super(props);
        this.state={
            res:'',
        }
    }
    componentDidMount(){
        axios.get('http://goldenfuturelife.in/test/api.php')
      .then(response => {
          var res= response.data;
          this.setState({res});
      })
      .catch(error => {
        console.log(error);
      })
    }
    render() {
        
        return (
            
            <div>
                <Header res={this.state.res} />
                <div className="main">
                    <div className="banner-text-w3ls" id="home" style={{'background': 'url('+ this.state.res.bannerImage +') no-repeat top'}}>
                        <div className="container">
                            <div className="mx-auto text-center">
                                <h3 style={{'fontSize':this.state.res.h3 ,'color':this.state.res.hColor}}>Nibh eleifend nulla nascetur pharetra
				</h3>
                                <p className="banp mx-auto mt-3" style={{'fontSize':this.state.res.p ,'color':this.state.res.pColor}}>Nulla pellentesque mi non laoreet eleifend. Integer porttitor mollisar lorem, at molestie arcu  </p>
                                <a className="btn btn-primary mt-lg-5 mt-3 agile-link-bnr" href="#about" role="button">Learn More</a>
                            </div>
                        </div>
                    </div>
                    <About res={this.state.res} />
                    <Services res={this.state.res} />
                    <News res={this.state.res} />
                    <Contact res={this.state.res} />

                </div>
            </div>

        );
    }
}

export default Page;
