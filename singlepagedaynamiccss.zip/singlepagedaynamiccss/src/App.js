import React, { Component } from 'react';
import Page from './view/page';

class App extends Component {
  render() {
    return (
      <div >
         <Page />
      </div>
    );
  }
}

export default App;
